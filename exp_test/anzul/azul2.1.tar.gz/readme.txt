#-----------------------------------------------
ABOUT AZUL CODE EDITOR

Azul Code Editor is a small text editor that has been made in tcl/tk. 
The editor provides the following features:
- does syntax highlighting in your code for bash, c/c++, php and tcl/tk
- a line counter
- It also can copy, paste and cut. 
- you can search text
- very well known icons to let you know their meaning


#-----------------------------------------------
INSTALLATION

1. Uncompress the tar.gz file this way
	tar xzvf azul2.1.tar.gz
2. Just run the install program
	./install
3. To run the editor just type azul either on a terminal window or inside a "run command"
dialog window.

#-----------------------------------------------
COMMON PROBLEMS

1. I can't print?
You must install enscript package in order to print

